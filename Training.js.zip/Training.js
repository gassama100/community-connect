import React, { useState, useEffect, useContext } from "react";
import defaultImg from '../assets/defaultImg.png'
import {
    Button,
    Card,
    CardContent,
    Checkbox,
    FormControlLabel,
    Grid,
    IconButton,
    InputAdornment,
    makeStyles,
    Modal,
    Paper,
    Slider,
    TextField,
    Typography,
    MenuItem,
    Box,
    Avatar
} from "@material-ui/core";
import axios from 'axios'

import Rating from "@material-ui/lab/Rating";
import { SetPopupContext } from "../App";
import apiList from "../lib/apiList";
import { userType } from "../lib/isAuth";

const useStyles = makeStyles((theme) => ({
    container: {
        display: 'flex',
        flexDirection: 'column ',
        justifyContent: 'center',
        alignItems: 'center',
        gap: '50px',
        width: '100vw',
        padding:'20px 0px'
        // padding: theme.spacing(3),
    },
    cardItemContainer: {
        display: 'flex',
        justifyContent:'center',
        gap: '20px',
        padding: '20px'
    },
    cardItem: {
        width: '350px'
        // padding: theme.spacing(3),
    },
    root: {
        flexDirection: 'row',
        padding: theme.spacing(3),
    },
    jobCard: {
        marginBottom: theme.spacing(2),
        borderRadius: 20,
    },
    jobCardTitle: {
        fontWeight: '900',
        marginBottom: 10
        // textAlign:'center'

    },
    applyButton: {
        marginLeft: "auto",
        marginTop: 20,
        width: '100%'
    },
    modalPaper: {
        padding: theme.spacing(3),
        outline: "none",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        minWidth: "50%",
        alignItems: "center",
    },
}));


const Training = ({ job }) => {
    const classes = useStyles();
    const setPopup = useContext(SetPopupContext);
    const [profileDetails, setProfileDetails] = useState({
        name: "",
        education: [],
        skills: [],
        // profile: newResume.name,
        // resume: 'albaddev',
    });


    // ......................................

    //.......................................



    return (
        <Grid item lg={12} md={12} sm={6} className={classes.container}>
            <Typography variant="h1" className={classes.jobCardTitle} style={{ color: '#282876', fontSize: '72px', lineHeight: '95px', fontWeight: 700 }}>Welcom to the Training Center</Typography>

            <p style={{ color: '#282876', fontSize: '18px', lineHeight: '25px', width: '700px' }}>
                Welcome to your gateway to unlocking your full potential through comprehensive skills development training. Whether you're looking to enhance your professional abilities or acquire new talents, we offer a diverse range of courses designed to meet your needs, available both online and on-site.
            </p>

            <Grid container className={classes.cardItemContainer}>
                <Card className={classes.cardItem}>
                    <CardContent >
                        <Box item display='flex' flexDirection="column" justifyContent="flex-start" alignItems="flex-start" style={{marginTop:'100px'}} >
                            <Typography variant="h5" className={classes.jobCardTitle} >Best Practices for Cleaning, Sanitizing</Typography>
                            <Typography variant="body1">Posted By: Albad recruiter</Typography>
                        </Box>
                        <br />
                        <Button variant="contained" color="primary"  className={classes.applyButton} >
                            <a href='https://www.youtube.com/watch?v=nRnRQrlegi4'  target="_blank"  style={{textDecoration:'none',color:'#fff'}}>Go To Class</a>
                        </Button>
                    </CardContent>
                </Card>

                <Card className={classes.cardItem}>
                    <CardContent >
                    <Box item display='flex' flexDirection="column" justifyContent="flex-start" alignItems="flex-start" style={{marginTop:'100px'}} >
                            <Typography variant="h5" className={classes.jobCardTitle} > Plumbing Works (From Start to Finish) </Typography>
                            <Typography variant="body1">Posted By: Albad recruiter</Typography>
                        </Box>
                        <br />
                        <Button
                            variant="contained"
                            color="primary"
                            className={classes.applyButton}
                        >
                          <a href='https://www.youtube.com/watch?v=8jxRn-T_LCs'  target="_blank"  style={{textDecoration:'none',color:'#fff'}}>Go To Class</a>
                            
                        </Button>
                    </CardContent>
                </Card>


                <Card className={classes.cardItem}>
                    <CardContent >
                    <Box item display='flex' flexDirection="column" justifyContent="flex-start" alignItems="flex-start" style={{marginTop:'100px'}} >
                            <Typography variant="h5" className={classes.jobCardTitle} >Make a Website With WordPress (Beginners)</Typography>
                            <Typography variant="body1">Posted By: Albad recruiter</Typography>
                        </Box>
                        <br />
                        
                        <Button
                            variant="contained"
                            color="primary"
                            className={classes.applyButton}
                        >
                             <a href=' https://www.youtube.com/watch?v=O79pJ7qXwoE'  target="_blank"  style={{textDecoration:'none',color:'#fff'}}>Go To Class</a>
                          
                        </Button>
                    </CardContent>
                </Card>



                <Card className={classes.cardItem}>
                    <CardContent >
                    <Box item display='flex' flexDirection="column" justifyContent="flex-start" alignItems="flex-start" style={{marginTop:'100px'}} >
                            <Typography variant="h5" className={classes.jobCardTitle} >Internal Painting - SP Hand Skills Training </Typography>
                            <Typography variant="body1">Posted By: Albad recruiter</Typography>
                        </Box>
                        <br />
                        
                        <Button
                            variant="contained"
                            color="primary"
                            className={classes.applyButton}
                        >
                             <a href='https://www.youtube.com/watch?v=GhKO0u92ef4'  target="_blank"  style={{textDecoration:'none',color:'#fff'}}>Go To Class</a>
                            
                        </Button>
                    </CardContent>
                </Card>

            </Grid>
        </Grid>
    )
}
export default Training