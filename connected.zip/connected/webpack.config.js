module.exports = {
    resolve: {
        fallback: {
          "tty": require.resolve("tty-browserify")
        }
      }
  };