import React, { useContext, useState } from 'react'
import axios from 'axios'
import { LoginContext } from '../context/authContext'
import { Card, Modal, Button, FormControl } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import style from '../styles/UpdateBusinessLogo.module.scss'
import { useMutation, useQueryClient } from 'react-query'

//icons
import { BsCardImage } from 'react-icons/bs'
import { makeRequest } from '../axios'
import { MdAddAPhoto } from 'react-icons/md'

import loader from "../assets/images/page-img/page-load-loader.gif";
//...img
import img1 from "../assets/images/small/07.png";
import { useForm, useWatch } from 'react-hook-form'





const UpdateBusinessLogo = ({businessLogo}) => {

const { currentUser } = useContext(LoginContext)
const [isLoading, setLoading] = useState(false)
const { register,control,getValues, handleSubmit, formState: { errors } } = useForm();
  useWatch({
    control
    //, name: "comment_Content", // without supply name will watch the entire form, or ['firstName', 'lastName'] to watch both
  });

    //CREATE DATA STATE
    const [profileFile, setProfileFile] = useState(null)


    // FORMAT post_Avatar FOR DB READY .post_Avatarname

    const upload = async () => {
        try {
            // WE CREATE a set Object AND CREATE A NEW FILE
            const formData = new FormData()
            formData.append("file", profileFile)
            const res = await makeRequest.post("/upload", formData)
            return res.data
        } catch (error) {
            console.log(error)
        }
    }

    //......................................


 

    const handleImgChange = (e) => {
        setProfileFile(e.target.files[0])
    }


    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const queryClient = useQueryClient()

    
    // WE USE REACT QUERY MUTATION TO MAKE OUR NEW POST ASYNC WITH THE POST COMPONENT

    const mutation = useMutation(
        async (newLogo) => {
            return  await makeRequest.post("/updateBusinessLogo", newLogo)
           
        },
        {
            onSuccess: () => {
                // invalidate and refetch
                queryClient.invalidateQueries('business')
            }
        }
    )



    const handleClick = async () => {
        setLoading(true)

        try {
            let imgUrl = ""

            //....MUTATION FOR PROFILE IMAGE
            if (profileFile) imgUrl = await upload()
            mutation.mutate({ Business_Logo: imgUrl })

        }catch(error) {
            console.log(error)
        }
        setLoading(false)
        handleClose()
    }


    // ,....SET IMG SRC
    const profilP = (profileFile )  ? URL.createObjectURL(profileFile) : businessLogo ? businessLogo : "https://d28yzi4k0o1l22.cloudfront.net/defaultbLogo.jpg"
   
  


    return (
        <div>
            <div className={style.CardHeader}>
                
                <div >
                    
                    <div className={style.header}>
                        {/* <i className="ri-pencil-line h4"></i> */}
                        <div className="data ms-2">
                            <h6> <MdAddAPhoto className={style.addImgIcon} onClick={handleShow} /> </h6>
                            {/* <p className="mb-0" onClick={handleShow} >
                            Update your profile image
                        </p> */}
                        </div>
                    </div>
                </div>
            </div>

            <Card id="post-modal-data" className="card-block card-stretch card-height" >
                <Modal size="md" className=" fade" id="post-modal" onHide={handleClose} show={show} >
                    <Modal.Header className="d-flex justify-content-between">
                        <Modal.Title id="post-modalLabel">Update Business Logo </Modal.Title>
                        <Link to="#" className="lh-1" onClick={handleClose} >
                            <span className="material-symbols-outlined">close</span>
                        </Link>
                    </Modal.Header>
                    <Modal.Body className={style.container}>
                        <div className={style.imgContainer}>
                            {/* <div className={style.coverContainer}>
                                <div className={style.coverDiv}>
                                    <img src={profilCover} alt="user1" className={style.pImage}/>
                                </div>
                            </div> */}
                            {
                                profilP ?
                                    <div className={style.imageDiv} >
                                        {/*URL.createObjectURL(file)  */}

                                        <img src={profilP} alt="user1" className={style.pImage}/>
                                    </div>
                                : null
                                     
                            }    

                        </div>

                        <div className="col-sm-12 text-center" style={{display: isLoading ? "flex" : "none", justifyContent:"center", alignItems:"center"}}>
                            <img
                                loading="lazy"
                                src={loader}
                                alt="loader"
                                style={{ height: "100px" }}
                            />
                        </div>


                        <form   >
                            {/* <div className={style.cardContainer}>
                                <div className=' gap-2'>
                                    <form className="d-flex flex-dir-column post-text ms-3 w-100 " data-bs-toggle="modal" data-bs-target="#post-modal">
                                        <input type="file" value={newPost_Name} onChange={handleTitleChange} className="form-control rounded" placeholder="Enter Post Title" style={{ border: "none" }} />
                                    </form>
                                    {/* <div class="form-outline">
                                    <textarea value={newPost_Content} onChange={(e) => setNewPost_Content(e.target.value)} class="form-control" id="textAreaExample"  rows="5" cols="50"  />
                                    </div> 
                                </div> 

                            </div>*/}
                            <hr />
                            <div className="col-md-6 mb-3">
                                <Button id={style.uploadIcon}>
                                    <input {...register("imgProfile", {required: true,
                                        validate: {
                                        //fileRequered:   (files) => files[0]?.size  || "Image field can't be empty !",
                                          acceptedFormats: (files) =>
                                            ["image/jpeg", "image/png", "image/gif"].includes(
                                              files[0]?.type
                                            ) || "Only PNG, JPEG e GIF"
                                        }        
                                })} 
                                    type='file' name="imgProfile" onChange={handleImgChange} required={true}/><BsCardImage className={style.icon} /> Photo
                                </Button>
                                {errors.imgProfile && <span>Image can be Only PNG, JPEG or GIF !</span>}
                            </div>
                            <button type="submit" onClick={handleSubmit( handleClick)} id={style.submitBtn} className="btn btn-primary d-block w-100 mt-3">Save</button>
                        </form>
                    </Modal.Body>
                </Modal>
            </Card>
        </div>
    )
}


export default UpdateBusinessLogo