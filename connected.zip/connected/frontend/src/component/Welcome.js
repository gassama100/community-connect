import { Grid, Typography, makeStyles } from "@material-ui/core";
import portalImg from '../../src/assets/portalImg.png'
import { Link } from "react-router-dom";


const useStyles = makeStyles((theme) => ({
  container: {
    width: '100%',
  },
  link: {
    borderRadius:'10px',
    color:'#008DDA',
    '&:hover': {
      background: "#008DDA",
      color:'#fff',
      fontWeight:'600',
      borderRadius:'5px'
   },
  }
}))



export const Welcome = (props) => {
  const classes = useStyles();
  return (
    <Grid
      container
      //className={classes.container}
      //backgroundImage= url('https://www.workindia.in/employers/_next-images/?url=http%3A%2F%2Fresources.workindia.in%2Femployer%2Fassets%2Fimg%2Flanding_hero.png&w=3840&q=75')
      //  backgroundRepeat:'no-repeat',
      //  backgroundSize:'500px',
      // item
      display='flex'
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      style={{ padding: "30px", minHeight: "93vh" }}

    >
      <Grid container display='flex' justifyContent="center" width='100%' style={{ marginBottom: '50px' }}>
        <img width={400} height={300} src={portalImg} />
      </Grid>
      <Grid  container display='flex' flexDirection='column' justifyContent="center" alignItems="center"  style={{ marginTop: '-100px',}}>
        <Typography variant="h1" align="center" style={{ color: '#282876', fontSize: '72px', lineHeight: '95px', fontWeight: 700 }} gutterBottom>Welcome to Community-Connect <br /> Job Portal</Typography>
       
        {/* Replace Button with Link */}
        <Grid style={{ display:'flex',justifyContent:'center',gap:'150px',width:'100%', marginTop:'20px' }}>
          <div  style={{backgroundColor:'#008DDA',padding:'10px 40px',borderRadius:'10px'}}>
            <Link to="/signup" style={{ textDecoration: 'none', color:'#fff'}}>
              <Typography variant="button" color="#fff">Register Now </Typography>
            </Link>
          </div>
         
            <Link to="/login"  className={classes.link} style={{textDecoration: 'none', border:'1px solid #008DDA',padding:'10px 40px'}} >
                 Log In
              {/* <Typography className={classes.link} variant="button" color="#fff"> </Typography> */}
            </Link>
          
          
        </Grid>

      </Grid>



    </Grid>
  );
};

export const ErrorPage = (props) => {
  return (
    <Grid
      container
      item
      direction="column"
      alignItems="center"
      justify="center"
      style={{ padding: "30px", minHeight: "93vh" }}
    >
      <Grid item>
        <Typography variant="h2">Error 404</Typography>
      </Grid>
    </Grid>
  );
};

export default Welcome;
