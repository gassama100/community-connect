const express = require("express");
const multer = require("multer");
const fs = require("fs");
const { v4: uuidv4 } = require("uuid");
const { promisify } = require("util");

const pipeline = promisify(require("stream").pipeline);

const router = express.Router();

// Multer configuration for file upload
const storage = multer.diskStorage({
  destination:  function(req,  file,  cb)  {
   cb(null, "./public/profile")
  },
  filename:function(req, file, cb) {
    cb(null,file.originalname)
  }
});

const storageResume = multer.diskStorage({
  destination:  function(req,  file,  cb)  {
   cb(null, "./public/resume")
  },
  filename:function(req, file, cb) {
    cb(null,file.originalname)
  }
});

const upload = multer({ storage: storage });

const uploadResume = multer({ storage: storageResume });

// const upload = multer();

router.post("/resume", uploadResume.single("file"), (req, res) => {

  const file = req.file 
  res.status(200).json(file.filename)
  // const { file } = req;
  // if (file.detectedFileExtension != ".pdf") {
  //   res.status(400).json({
  //     message: "Invalid format",
  //   });
  // } else {
  //   const filename = `${uuidv4()}${file.detectedFileExtension}`;

  //   pipeline(
  //     file.stream,
  //     fs.createWriteStream(`${__dirname}/../public/resume/${filename}`)
  //   )
  //     .then(() => {
  //       res.send({
  //         message: "File uploaded successfully",
  //         url: `/host/resume/${filename}`,
  //       });
  //     })
  //     .catch((err) => {
  //       res.status(400).json({
  //         message: "Error while uploading",
  //       });
  //     });
  // }
});

// router.post("/profile", upload.single("file"), (req, res) => {
//   const { file } = req;
//   if (
//     file.detectedFileExtension === ".jpg" ||
//     file.detectedFileExtension === ".png"
//   ) {
//     res.status(400).json({
//       message: "Invalid format",
//     });
//   } else {
//     const filename = `${uuidv4()}${file.detectedFileExtension}`;


// pipeline(
//   file.stream,
//   fs.createWriteStream(`${__dirname}/../public/profile/${filename}`),
//   (err) => {
//     if (err) {
//       console.error("Pipeline failed.", err);
//     } else {
//       console.log("Pipeline succeeded.");
//     }
//   }
// )
//       .then(() => {
//         res.send({
//           message: "Profile image uploaded successfully",
//           url: `/host/profile/${filename}`,
//         });
//       })
//       .catch((err) => {
//         res.status(400).json({
//           message: "Error while uploading",
//         });
//       });
//   }
// });




router.post('/profile', upload.single('file'), (req, res) => {
  const file = req.file 
  res.status(200).json(file.filename)
});

module.exports = router;






    // pipeline(
    //   file.stream,
    //   fs.createWriteStream(`${__dirname}/../public/profile/${filename}`)
    // )

// Example file stream (replace this with your actual file stream)
//const fileStream = getYourFileStreamSomehow();








// // const express = require("express");
// const express  = require("express");
// const multer = require('multer');
// const fs = require("fs");
// const { v4: uuidv4 } = require("uuid");
// const { promisify } = require("util");

// const pipeline = promisify(require("stream").pipeline);

// const router = express.Router();

// const upload = multer();

// router.post("/resume", upload.single("file"), (req, res) => {
//   const { file } = req;
//   if (file.detectedFileExtension != ".pdf") {
//     res.status(400).json({
//       message: "Invalid format",
//     });
//   } else {
//     const filename = `${uuidv4()}${file.detectedFileExtension}`;

//     pipeline(
//       file.stream,
//       fs.createWriteStream(`${__dirname}/../public/resume/${filename}`)
//     )
//       .then(() => {
//         res.send({
//           message: "File uploaded successfully",
//           url: `/host/resume/${filename}`,
//         });
//       })
//       .catch((err) => {
//         res.status(400).json({
//           message: "Error while uploading",
//         });
//       });
//   }
// });

// router.post("/profile", upload.single("file"), (req, res) => {
//   const { file } = req;

//   // if (
//   //   file.detectedFileExtension != ".jpg" &&
//   //   file.detectedFileExtension != ".png"
//   // ) {
//   //   res.status(400).json({
//   //     message: "Invalid format",
//   //   });
//   // } else {
//   //   const filename = `${uuidv4()}${file.detectedFileExtension}`;

//   //   pipeline(
//   //     file.stream,
//   //     fs.createWriteStream(`${__dirname}/../public/profile/${filename}`)
//   //   )
//   //     .then(() => {
//   //       res.send({
//   //         message: "Profile image uploaded successfully",
//   //         url: `/host/profile/${filename}`,
//   //       });
//   //     })
//   //     .catch((err) => {
//   //       res.status(400).json({
//   //         message: "Error while uploading",
//   //       });
//   //     });
//   // }
//   // Serve static files from the 'public' directory



//   const storage = multer.diskStorage({
//     destination: function (req, file, cb) {
//       cb(null, "../public/profile")
//     },
//     filename: function (req, file, cb) {
//       cb(null,Date.now() + file.originalname )
//     }
//   })
  
//   const upload = multer({ storage: storage })

//   app.use(express.static('public'));


//   app.post('/upload/profile', upload.single('file'), (req, res) => {
//     const file = req.file;
//     if (!file) {
//       return res.status(400).json({ error: 'No file uploaded' });
//     }
//     res.status(200).json({ fileName: file.filename });
//   });
//   // app.post("/upload/profile", upload.single("file"), (req, res) => {
//   //   const file = req.file
//   //   res.status(200).json(file.filename)
//   // })

// });

// module.exports = router;
